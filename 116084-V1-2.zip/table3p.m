%========================================================================= 
% table3p.m
%
% produce table3 in ��Do Technological Improvements 
% in the Manufacturing Sector Raise or Lower Employment? 
% (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
%
% input: data files
%        manu2.dat
%
% requires: sicall.m varlr1.m, irflr1.m, bootstrap1.m  (routines)
%
% output: table3p.txt
% 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu
%=========================================================================

clc
clear all
close all

set(0,'DefaultLineLineWidth',1)
set(0,'DefaultAxesLineWidth',1)
set(0,'DefaultAxesFontSize',10)

%-------------------------------------------------------------------------
% load dataset
%-------------------------------------------------------------------------
cd ./routine
sicall
cd ..
sicN = size(sic,1);
cd ./data
load manu2.dat
cd ..
nber=manu2;
% sic year tfp dp dn dk dm

g_var = MENU('generate variance?','No','Yes');


Sim = 500;                     % Total number of simulation to get variance


digit2 = sic(find(mod(sic,100)==0));
digit3 = sic(find(mod(sic,10)==0 & mod(sic,100)~=0));
digit4 = sic(find(mod(sic,10)~=0));

durable = [2400; 2500; 3200; 3300; 3400; 3500; 3600; 3700; 3800; 3900];
nondurable = [2000; 2100; 2200; 2300; 2600; 2700; 2800; 2900; 3000; 3100];


outlog = [];
table3=zeros(4,2);
sig=['  ';'  ';'  '];

siccode = sic(find(mod(sic,10)==0),:);
siccode = [0;1;2;siccode];
for sicn=1:size(siccode,1)

     if siccode(sicn)==0
        temp_sic = digit2;
     elseif siccode(sicn)==1
        temp_sic = durable;
     elseif siccode(sicn)==2
        temp_sic = nondurable;
     elseif mod(siccode(sicn),100)==0
        temp_sic = ...
	digit3(find(digit3>siccode(sicn) & digit3<siccode(sicn)+100),:);
     else
        temp_sic = ...
	digit4(find(digit4>siccode(sicn) & digit4<siccode(sicn)+10),:);
     end

     vset = size(temp_sic,1);
     series = [];

     for i_vset=1:vset
         data = nber(find(nber(:,1)==temp_sic(i_vset)),3:5);
         series = [series;data(:,[2,3])];  % [dtfp, dn]
     end

     cd ./routine
      %-------------------------------------------------------------------------
      % VAR model
      %-------------------------------------------------------------------------
      p = 1;                         % Order of VAR lag 
      nIR = 50;                      % number of periods for Impulse Response
      nIRF = 5;                     % maximum periods shown in IRF graph

      [b,Sig,B]   = varlr1(series,p,vset); % VAR order of p
      IRF = irflr1(b,B,nIR,vset);    % Impulse response (or MA coefficients)
      IRF = [cumsum(IRF(1,:));cumsum(IRF(2,:));...
             cumsum(IRF(3,:));cumsum(IRF(4,:))];
                                     % to get IR to TFP, 
				     % sum all the coefficients of dTFP
      srr = IRF(2,1);     % short-run response
      
    
      %-------------------------------------------------------------------------
      % Bootstrap
      %------------------------------------------------------------------------- 
      if g_var ==2
      for sim=1:Sim
         series_b = bootstrap1(series,p,size(series,1)+30,vset);
                                     % Pseudo Series generated
         [b_b,Sig_b,B_b] = varlr1(series_b,p,vset);
         IRF_b = irflr1(b_b,B_b,nIR,vset);
         IRF1(sim,:) = cumsum(IRF_b(1,:));
         IRF2(sim,:) = cumsum(IRF_b(2,:));
         IRF3(sim,:) = cumsum(IRF_b(3,:));
         IRF4(sim,:) = cumsum(IRF_b(4,:));
	 srrsim(sim) = IRF2(sim,1);
      end

      stdsrr = std(srrsim);
      end
      cd ..
      %-------------------------------------------------------------------------
      % TABLE 2
      %------------------------------------------------------------------------- 
      if siccode(sicn)>1000
         if mod(siccode(sicn),100)==0     % 2 digit
	    rw=1;
	 elseif mod(siccode(sicn),10)==0  % 3 digit
	    rw=3;
	 end

	 if g_var==2
            sig2 = abs(srr/stdsrr)>=norminv(0.95); % 10% significance
         end

	 if srr<0
	    cl=1;
	 else
	    cl=2;
	 end

	 table3(rw,cl)=table3(rw,cl)+1;
	 if g_var==2 & sig2==1
	    table3(rw+1,cl)=table3(rw+1,cl)+1;
	 end
      end
 end
 
delete('result/table3p.txt')
diary('result/table3p.txt')
disp(['Created  ' datestr(now)])
disp(' ')
disp('Program Used "table13p.m"')
disp(' ')
disp('=================================================================')
disp('  VAR MODEL with (dLP,dlog(total hour))')   
disp('  estimated by PANEL method')
disp('=================================================================')
disp('  SRR result')
disp('  2 digit, 3 digit PANEL')
disp('  NEGATIVE    POSITIVE')
disp('=================================================================')
disp(num2str(table3))
disp('=================================================================')
diary off 