%========================================================================= 
% figure4.m
%
% produce figure4 in ��Do Technological Improvements 
% in the Manufacturing Sector Raise or Lower Employment? 
% (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
%
% input: data files
%        manu_perhour.dat
%
% requires: varlr.m, irflr.m, bootstrap.m,
%           band.m, bandplot.m (routines)
%
% output: fig4_N_L.eps, fig4_L_L.eps, fig4_K_L.eps
% 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu
%=========================================================================

clc
clear all
close all

set(0,'DefaultFigurePaperPosition', [0 4 8.5 3.5])

set(0,'DefaultLineLineWidth',2)
set(0,'DefaultAxesLineWidth',1)
set(0,'DefaultAxesFontSize',13)


%-------------------------------------------------------------------------
% load dataset
%-------------------------------------------------------------------------

cd ./data
load manu_perhour.dat; 
cd ..

data = manu_perhour; % d(n-l) d(m-l) d(k-l) dl

for d_input = 1:3 %1: non-labor input 2: material 3:capital

if d_input ==1
    data2(:,1) = data(:,1); %d(n-l)
elseif d_input == 2
    data2(:,1) = data(:,2); %d(m-l)
elseif d_input == 3
    data2(:,1) = data(:,3); %d(k-l)
end
data2(:,2) = data(:,4);
series = data2;

clear data2
[rn,cn] = size(series);  % rn : # of observation
                         % cn : # of variables

%-------------------------------------------------------------------------
% set some parameters
%-------------------------------------------------------------------------
Sim = 500;                     % Total number of simulation to get variance
p = 1;                         % lag of VAR order

cd ./routine
%-------------------------------------------------------------------------
% VAR model
%-------------------------------------------------------------------------

nIR = 50;                      % number of periods for Impulse Response
nIRF = 5;                     % maximum periods shown in IRF graph

[b,Sig,B]   = varlr(series,p); % VAR order of p
IRF = 100*irflr(b,B,nIR);          % Impulse response (or MA coefficients)
IRF = cumsum(IRF')';           % To get IR to TFP, 
                               % sum all the coefficients of dTFP
  
%-------------------------------------------------------------------------
% Bootstrap
%------------------------------------------------------------------------- 
disp('Bootstraping.......')
for sim=1:Sim
    series_b = bootstrap(series,p,size(series,1)+30);
                                     % Pseudo Series generated
    [b_b,Sig_b,B_b] = varlr(series_b,p);
    IRF_b = 100*irflr(b_b,B_b,nIR);
    IRF1(sim,:) = cumsum(IRF_b(1,:));
    IRF2(sim,:) = cumsum(IRF_b(2,:));
    IRF3(sim,:) = cumsum(IRF_b(3,:));
    IRF4(sim,:) = cumsum(IRF_b(4,:));
end
disp('Finished!'); disp(' ')  

band1 = band(IRF1,.90);
band2 = band(IRF2,.90);
band3 = band(IRF3,.90);
band4 = band(IRF4,.90);


cd ..
%-------------------------------------------------------------------------
% Draw IRF and Confidence Interval
%-------------------------------------------------------------------------

      
nir = 50;       % # of period in IRF graph

if nir>nIRF
  nir = nIRF;
end


t = 1:nir+1;
   
figure

cd ./routine
    subplot(1,2,1)
    bandplot(t-1,band1(:,1:nIRF+1))
    hold on
    plot(t-1,IRF(1,1:nir+1),'k-',t-1,zeros(1,nir+1),'k:')
    xlabel('year'); ylabel('percent'); 
    
    if d_input ==1
        title(['Non-Labor Input per Hour'])
    elseif d_input ==2
        title(['Material per Hour'])
    elseif d_input ==3 
        title(['Capital per Hour'])
    end
      
    subplot(1,2,2)
    bandplot(t-1,band2(:,1:nIRF+1))
    hold on
    plot(t-1,IRF(2,1:nir+1),'k-',t-1,zeros(1,nir+1),'k:')
    title(['Hours'])
    xlabel('year'); ylabel('percent'); 
cd ..    
   if d_input ==1
     print ./result/fig4_N_L -depsc
    elseif d_input ==2
    print ./result/fig4_M_L -depsc
    elseif d_input ==3 
     print ./result/fig4_K_L -depsc
    end
end