%========================================================================= 
% figure2a.m
%
% produce figure2 in ��Do Technological Improvements 
% in the Manufacturing Sector Raise or Lower Employment? 
% (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
%
% input: data files
%        manu2.dat sticky_month.dat
%
% requires: sicall.m varlr.m, irflr.m, bootstrap.m  (routines)
%
% output: figure2_log_srr.txt fig2.eps
% 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu
%=========================================================================

clc
clear all
close all


% load data sets
cd ./routine
sicall
cd ..
sicN = size(sic,1);
cd ./data
load sticky_month.dat

load manu2.dat
nber=manu2;
clear manu2
cd ..
  % sic year tfp dp dn dk dm

delete('result/figure2_log_srr.txt')
diary('result/figure2_log_srr.txt')
disp('SIC   duration   srr(TFP)   srr(LP)')
cor_gr = [];

for sici = 1:size(sticky_month,1)

     data = nber(find(nber(:,1)==sticky_month(sici,1)),3:5);
     % tfp, dp, dn
      series1 = data(:,[1,3]); % [tfp, dn]
      series2 = data(:,[2,3]); % [dp, dn]

      cd ./routine
      %-------------------------------------------------------------------------
      % VAR model
      %-------------------------------------------------------------------------
      p = 1;                         % Order of VAR lag 
      nIR = 50;                      % number of periods for Impulse Response
      nIRF = 15;                     % maximum periods shown in IRF graph

      % TFP SHOCK MODEL

      [b,Sig,B]   = varlr(series1,p); % VAR order of p
      IRF = irflr(b,B,nIR);          % Impulse response (or MA coefficients)
      IRF = [cumsum(IRF(1,:));cumsum(IRF(2,:));cumsum(IRF(3,:));cumsum(IRF(4,:))];
                                     % to get IR to TFP, 
				     % sum all the coefficients of dTFP
      srr1 = IRF(2,1)/IRF(1,end);    % short-run response

      % LP SHOCK MODEL

      [b,Sig,B]   = varlr(series2,p); % VAR order of p
      IRF = irflr(b,B,nIR);          % Impulse response (or MA coefficients)
      IRF = [cumsum(IRF(1,:));cumsum(IRF(2,:));cumsum(IRF(3,:));cumsum(IRF(4,:))];
                                     % to get IR to TFP, 
				     % sum all the coefficients of dTFP
      srr2 = IRF(2,1)/IRF(1,end);    % short-run response
     
      cor_gr = [cor_gr; sticky_month(sici,:), srr1, srr2];
      % [sic, duration, srr(tfp), srr(lp)]
      output = [num2str(cor_gr(end,1),'%4i'), '  ', num2str(cor_gr(end,2),'%4.2f') , '   ',...
       num2str(cor_gr(end,3:4),'%10.4f')];
      cd ..
      diary on
      disp(output)
      diary off

end


% Calculate correlation coefficients (duration, srr)

coef1 = corrcoef(cor_gr(:,[2,3]));
coef2 = corrcoef(cor_gr(:,[2,4]));
coef = [coef1(1,2),coef2(1,2)];

temp_gr = [log(cor_gr(:,2)),cor_gr(:,3:4)];

% some graphical handles

set(0,'DefaultFigurePaperOrientation','landscape')
set(0,'DefaultFigurePaperPosition', [0.5 1.75 8.5 4.5])
set(0,'DefaultLineLineWidth',1.2)
set(0,'DefaultAxesLineWidth',1)
set(0,'DefaultAxesFontSize',12)

figure(2)
subplot(1,2,1)
plot(temp_gr(:,1),temp_gr(:,2),'*')
xlabel('log(duration)')
ylabel('short-run response')
title('TFP Shock')
axis([-1,4,-2,2])
coeftxt = ['cor(srr,duration) = ',num2str(coef(1),'%4.2f')];
text(0,1.6,coeftxt,'FontSize',12)
subplot(1,2,2)
plot(temp_gr(:,1),temp_gr(:,3),'*')
xlabel('log(duration)')
ylabel('short-run response')
title('Labor Productivity Shock')
axis([-1,4,-2,2])
coeftxt = ['cor(srr,duration) = ',num2str(coef(2),'%4.2f')];
text(0,1.6,coeftxt,'FontSize',12)
print -depsc2 ./result/fig2
