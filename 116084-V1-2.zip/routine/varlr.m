function [b,Sig,B]   = varlr(series,p)
% VARLR Vector Autoregression with Long-Run restriction
%  See Blanchard-Quah restriction (89)
%  [b,Sig,B] = varlr(series,p)
%   b: VAR coefficient vector [A0,A1,...,Ap]'
%   Sig: Variance-Covariance Matrix of Reduced form error
%   B: Structual transform Matrix
%      computed with longrun restriction imposed
%
%   p: VAR order
  
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu

[nobs,nvar] = size(series);

YY = series(p+1:nobs,:);
XX = ones(nobs-p,1+nvar*p);

for i = 1:p
   XX(:,2+nvar*(i-1):1+nvar*i) = series(p+1-i:nobs-i,:);
end

b = inv(XX'*XX)*XX'*YY;
e = YY - XX*b;
Sig = (e'*e)/(nobs-p);
AR = b(2:end,:)';            % AR coefficient [A1,A2,...,Ap]

% MA representation
%
% Y_t = A0 + A1*Y_(t-1) + ... + Ap*Y_(t-p) + e_t   :: AR (p)
%
% Y_t = mu + Phi(L)*e_t  :: MA(infinity)
% where  Phi(L) = (I-A1*L-A2*L^2-...-Ap*L^p)^(-1)
% mu = Phi(1)*A0

Phi1 = inv(eye(nvar)- AR*repmat(eye(nvar),p,1)); 
mu = Phi1*b(1,:)';

lvar = Phi1*Sig*Phi1';

% Long-Run restriction
% define 
% Y_t = theta(L)*epsilon_t
% where var(epsilon_t) = I
% Let e_t = B*epsilon_t so that Phi(L)*B = theta(L)
% Note that BB' = Sig
% the longrun variance of Y is theta(1)*theta(1)'
% long-run restriction here is theta(1) is lower triangular matrix

theta1 = chol(lvar)';
B = inv(Phi1)*theta1;