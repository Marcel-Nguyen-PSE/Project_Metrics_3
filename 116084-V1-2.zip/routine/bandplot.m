function varargout = bandplot(x,y,mm)
%BANDPLOT Linear plot with continuous confidence/error boundaries.
%
%   CONFPLOT(X,Y,L,U) plots the graph of vector X vs. vector Y with
%   'continuous' confidence/error boundaries specified by the vectors
%   L and U.  L and U contain the lower and upper error ranges for each
%   point in Y. The vectors X,Y,L and U must all be the same length.  
%
%   CONFPLOT(X,Y,E) or CONFPLOT(Y,E) plots Y with error bars [Y-E Y+E].
%   CONFPLOT(...,'LineSpec') uses the color and linestyle specified by
%   the string 'LineSpec'.  See PLOT for possibilities.
%
%   H = CONFPLOT(...) returns a vector of line handles.
%
%   For example,
%      x = 1:0.1:10; 
%      y = sin(x);
%      e = std(y)*ones(size(x));
%      confplot(x,y,e)
%   draws symmetric continuous confidence/error boundaries of unit standard deviation.
%
%   See also ERRORBAR, SEMILOGX, SEMILOGY, LOGLOG, PLOTYY, GRID, CLF, CLC, TITLE,
%   XLABEL, YLABEL, AXIS, AXES, HOLD, COLORDEF, LEGEND, SUBPLOT, STEM.
%
%     � 2002 - Michele Giugliano, PhD (http://www.giugliano.info) (Bern, Monday Nov 4th, 2002 - 19:02)
%    (bug-reports to michele@giugliano.info)
%   $Revision: 1.0 $  $Date: 2002/11/11 14:36:08 $
%                        
%  minor modification by
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu


if (nargin<2)
 disp('ERROR: not enough input arguments!');
 return;
end % if

p = plot(x,y);    YLIM = get(gca,'YLim');    delete(p);
if (nargin==2)
 mm=min(YLIM);
end
a1 = area(x,y(2,:),mm); 
hold on;
set(a1,'LineStyle','none');     set(a1,'FaceColor',[0.8 0.8 0.8]);
a2 = area(x,y(1,:),mm-0.01); 
set(a2,'LineStyle','none');     set(a2,'FaceColor',[1 1 1]);
set(gca,'Layer','top');               
H = [a1, a2];

if (nargout>1) varargout{1} = H; end;
