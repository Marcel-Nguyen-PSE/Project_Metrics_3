function cor=cor(MA)
 
[a,b] = size(MA);
nvar = round(sqrt(a));
nIR = b-1; 

varmat = MA.^2;
covmat = MA([1,3],:).*MA([2,4],:);

cova = sum(covmat');
vari = sum(varmat');

unccor = sum(cova)/(sqrt(vari(1)+vari(3))*sqrt(vari(2)+vari(4)));
cor1 = cova(1)/(sqrt(vari(1))*sqrt(vari(2)));
cor2 = cova(2)/(sqrt(vari(3))*sqrt(vari(4)));

cor = [unccor, cor1, cor2];

