function [b,Sig,B]   = varlr1(series,p,vset)
% VARLR Vector Autoregression with Long-Run restriction
%  See Blanchard-Quah restriction (89)
%  [b,Sig,B] = varlr(series,p)
%   b: VAR coefficient vector [A0,A1,...,Ap]'
%   Sig: Variance-Covariance Matrix of Reduced form error
%   B: Structual transform Matrix
%      computed with longrun restriction imposed
%
%   p: VAR order
  
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu

[Tnobs,nvar] = size(series);


nobs = Tnobs/vset; 


YY = [];
XX = [];
for i_vset = 1:vset
   
   temp_data = series((nobs*(i_vset-1)+1):(nobs*i_vset),:);
   y_temp = temp_data((p+1):(nobs),:);
   x_temp = zeros((nobs-p),(vset+nvar)*p);
   x_temp(:,i_vset) = ones((nobs-p),1);
   
   for i = 1:p
      x_temp(:,(vset+1+nvar*(i-1)):(vset+nvar*i)) = temp_data((p+1-i):(nobs-i),:);
   end
   YY = [YY;y_temp];
   XX = [XX;x_temp];
end


b = inv(XX'*XX)*XX'*YY;
e = YY - XX*b;
Sig = (e'*e)/(Tnobs-p);
AR = b(vset+1:end,:)';            % AR coefficient [A1,A2,...,Ap]

% MA representation
%
% Y_t = A0 + A1*Y_(t-1) + ... + Ap*Y_(t-p) + e_t   :: AR (p)
%
% Y_t = mu + Phi(L)*e_t  :: MA(infinity)
% where  Phi(L) = (I-A1*L-A2*L^2-...-Ap*L^p)^(-1)
% mu = Phi(1)*A0

Phi1 = inv(eye(nvar)- AR*repmat(eye(nvar),p,1)); 

lvar = Phi1*Sig*Phi1';

% Long-Run restriction
% define 
% Y_t = theta(L)*epsilon_t
% where var(epsilon_t) = I
% Let e_t = B*epsilon_t so that Phi(L)*B = theta(L)
% Note that BB' = Sig
% the longrun variance of Y is theta(1)*theta(1)'
% long-run restriction here is theta(1) is lower triangular matrix

theta1 = chol(lvar)';
B = inv(Phi1)*theta1;