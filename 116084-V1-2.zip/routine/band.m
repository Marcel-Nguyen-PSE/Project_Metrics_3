function band=band(mat,ptg)
% BAND calculate minimum-distance interval 

% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu

[F,n] = size(mat);
mat = sort(mat); 
t = round((1-ptg)*F);
for i=1:n
temp = mat(end-t:end,i)-mat(1:t+1,i);

[m,I] = min(temp);
band(:,i) = mat([I,F-I],i);
end