function IR = irflr(b,B,nIR)
% IRFLR impulse response of VAR
%  IR = irflr(b,B,nIR)
%    b: VAR coefficents [A0,A1,...,Ap]'
%    B: Structual vector for error 
%    nIR: periods of IRF
%
%    IR: s-th column has (s-1) period of IRF
%         [ t(11) t(21) ... t(n1) t(12)....]'
%         t(ij) stands for effect of j shock on variable i
 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu


nvar = size(b,2);
AR = b(2:end,:)';
p = size(AR,2)/nvar;
MA = zeros(nvar,nvar*nIR);

m = min(nIR,p);

MA(:,1:m*nvar) = AR(:,1:m*nvar);

for i = 1:nIR-1
   z = nvar*min(i+p,nIR);
   MA(:,i*nvar+1:z) = MA(:,i*nvar+1:z) + MA(:,(i-1)*nvar+1:i*nvar)*AR(:,1:z-i*nvar);
end

theta = [eye(nvar),MA]*kron(eye(nIR+1),B);
IR = reshape(theta,nvar^2,nIR+1);