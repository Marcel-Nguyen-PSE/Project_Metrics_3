function yb = bootstrap1(y,p,k,vset)
 
% y : series
% p : order of lags
% k : # of initial trimming observation
% vset : number of set of series

% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu

[nobs,nvar] = size(y);


YY = [];
XX = [];
for i_vset = 1:vset
   
   temp_data = y(nobs/vset*(i_vset-1)+1:nobs/vset*i_vset,:);
   y_temp = temp_data(p+1:nobs/vset,:);
   x_temp = zeros(nobs/vset-p,vset+nvar*p);
   x_temp(:,i_vset) = ones(nobs/vset-p,1);
   
   for i = 1:p
      x_temp(:,vset+1+nvar*(i-1):vset+nvar*i) = temp_data(p+1-i:nobs/vset-i,:);
   end
   YY = [YY;y_temp];
   XX = [XX;x_temp];
end



b = inv(XX'*XX)*XX'*YY;
e = YY - XX*b;

% generating Pseudo-Sample

% Pseudo-Disturbance
T = size(YY,1)/vset;
segment = (1:T)/T;
eb = zeros(vset*(T+k+p),nvar);

for i=1:T+k+p
 u=rand(1,1);
 eb((T+k+p)*(0:vset-1)+i,:) = e(T*(0:vset-1)+min(find(segment>=u)),:);
end

% Pseudo-Sample
yb = zeros(vset*(T+k+p),nvar);
r = XX(T*(0:vset-1)+1,:);
for i=1:T+k+p
  yb((T+k+p)*(0:vset-1)+i,:) = r*b + eb((T+k+p)*(0:vset-1)+i,:,:);
  r = [r(:,1:vset),yb((T+k+p)*(0:vset-1)+i,:),r(:,vset+1:end-nvar)];
end

% trim dataset

yb_temp = [];
for ib = 1:vset
  yb_temp = [yb_temp;yb(((T+k+p)*(ib-1)+k+1):(T+k+p)*ib,:)];
end

yb = yb_temp;