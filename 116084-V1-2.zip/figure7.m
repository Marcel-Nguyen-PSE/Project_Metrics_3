%========================================================================= 
% figure7.m
%
% produce figure7 in ��Do Technological Improvements 
% in the Manufacturing Sector Raise or Lower Employment? 
% (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
%
% input: data files
%        aggregate.dat
%
% requires: varlr.m, irflr.m, bootstrap.m,
%           band.m, bandplot.m (routines)
%
% output: fig7_nonfarm_tfp.eps fig7_nonfarm_lp.eps
% 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu
%=========================================================================

clc
clear all
close all

set(0,'DefaultFigurePaperPosition', [0.1 1.75 8.8 4])

set(0,'DefaultLineLineWidth',2)
set(0,'DefaultAxesLineWidth',1)
set(0,'DefaultAxesFontSize',14)


%-------------------------------------------------------------------------
% load dataset
%-------------------------------------------------------------------------
cd ./data
load aggregate.dat; % contains year, TFP, Y, N (in levels)
year = aggregate(:,1);
data1 = log(aggregate(:,2:end));
data2 = diff(data1);
cd ..

[m n] = size(data2);

for d_prod = 1:2  % 1: TFP 2: LP
if d_prod== 1
data(:,1) = data2(:,1); %TFP
elseif d_prod == 2
data(:,1) = data2(:,2)-data2(:,3); %LP
end

data(:,2) = data2(:,3);
series = data;

clear data
[rn,cn] = size(series);  % rn : # of observation
                         % cn : # of variables

%-------------------------------------------------------------------------
% set some parameters
%-------------------------------------------------------------------------
Sim = 500;                     % Total number of simulation to get variance
p = 1;                         % lag of VAR order

%-------------------------------------------------------------------------
% VAR model
%-------------------------------------------------------------------------
cd ./routine
nIR = 50;                      % number of periods for Impulse Response
nIRF = 5;                     % maximum periods shown in IRF graph

[b,Sig,B]   = varlr(series,p); % VAR order of p
IRF = 100*irflr(b,B,nIR);          % Impulse response (or MA coefficients)
IRF = cumsum(IRF')';           % To get IR to TFP, 
                               % sum all the coefficients of dTFP
  
%-------------------------------------------------------------------------
% Bootstrap
%------------------------------------------------------------------------- 
disp('Bootstraping.......')
for sim=1:Sim
    series_b = bootstrap(series,p,size(series,1)+30);
                                     % Pseudo Series generated
    [b_b,Sig_b,B_b] = varlr(series_b,p);
    IRF_b = 100*irflr(b_b,B_b,nIR);
    IRF1(sim,:) = cumsum(IRF_b(1,:));
    IRF2(sim,:) = cumsum(IRF_b(2,:));
    IRF3(sim,:) = cumsum(IRF_b(3,:));
    IRF4(sim,:) = cumsum(IRF_b(4,:));
end
disp('Finished!'); disp(' ')  

band1 = band(IRF1,.90);
band2 = band(IRF2,.90);
band3 = band(IRF3,.90);
band4 = band(IRF4,.90);
cd ..

%-------------------------------------------------------------------------
% Draw IRF and Confidence Interval
%-------------------------------------------------------------------------

      
nir = 50;       % # of period in IRF graph

if nir>nIRF
  nir = nIRF;
end


t = 1:nir+1;

f1=figure;
    set(f1,'position',[1 1 800 400])

if d_prod == 1
cd ./routine
subplot(1,2,1)
    bandplot(t-1,band1(:,1:nIRF+1))
    hold on
    plot(t-1,IRF(1,1:nir+1),'k-',t-1,zeros(1,nir+1),'k:')
    title(['TFP'])
    xlabel('year'); ylabel('percent')
subplot(1,2,2)      
    bandplot(t-1,band2(:,1:nIRF+1))
    hold on
    plot(t-1,IRF(2,1:nir+1),'k-',t-1,zeros(1,nir+1),'k:')
    title(['Hours'])
    xlabel('year'); ylabel('percent')
cd ..
print ./result/fig7_nonfarm_tfp -depsc

elseif d_prod==2
cd ./routine
subplot(1,2,1)
    bandplot(t-1,band1(:,1:nIRF+1))
    hold on
    plot(t-1,IRF(1,1:nir+1),'k-',t-1,zeros(1,nir+1),'k:')
    title(['Labor Productivity'])
    xlabel('year'); ylabel('percent')
subplot(1,2,2)      
    bandplot(t-1,band2(:,1:nIRF+1))
    hold on
    plot(t-1,IRF(2,1:nir+1),'k-',t-1,zeros(1,nir+1),'k:')
    title(['Hours'])
    xlabel('year'); ylabel('percent')
cd ..
print ./result/fig7_nonfarm_lp -depsc    
end
end
