%========================================================================= 
% table6a_basu.m
%
% produce table6 in ��Do Technological Improvements 
% in the Manufacturing Sector Raise or Lower Employment? 
% (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
%
% input: data files
%        manu2_basu.dat
%
% requires: sicall.m varlr.m, irflr.m, bootstrap.m  (routines)
%
% output: table6aB.txt
% 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu
%=========================================================================


clc
clear all
close all

%-------------------------------------------------------------------------
% load dataset
%-------------------------------------------------------------------------
cd ./routine
sicall
cd ..
sicN = size(sic,1);
cd ./data
load manu2_basu.dat
cd ..
nber=manu2_basu;
% sic year tfp dp dn dk dm

g_var = MENU('generate variance?','No','Yes');


Sim = 500;                     % Total number of simulation to get variance

outlog = [];
table6=zeros(6,2);
sig=['  ';'  ';'  '];

siccode = sic;
siccode = [0;1;2;siccode];
for sicn=1:size(siccode,1)



     series = nber(find(nber(:,1)==siccode(sicn)),[3,5]);

     cd ./routine
      %-------------------------------------------------------------------------
      % VAR model
      %-------------------------------------------------------------------------
      p = 1;                         % Order of VAR lag 
      nIR = 50;                      % number of periods for Impulse Response
      nIRF = 5;                     % maximum periods shown in IRF graph

      [b,Sig,B]   = varlr(series,p); % VAR order of p
      IRF = irflr(b,B,nIR);    % Impulse response (or MA coefficients)
      IRF = [cumsum(IRF(1,:));cumsum(IRF(2,:));...
             cumsum(IRF(3,:));cumsum(IRF(4,:))];
                                     % to get IR to TFP, 
				     % sum all the coefficients of dTFP
      srr = IRF(2,1);     % short-run response
    
      %-------------------------------------------------------------------------
      % Bootstrap
      %------------------------------------------------------------------------- 
      if g_var ==2
      for sim=1:Sim
         series_b = bootstrap(series,p,size(series,1)+30);
                                     % Pseudo Series generated
         [b_b,Sig_b,B_b] = varlr(series_b,p);
         IRF_b = irflr(b_b,B_b,nIR);
         IRF1(sim,:) = cumsum(IRF_b(1,:));
         IRF2(sim,:) = cumsum(IRF_b(2,:));
         IRF3(sim,:) = cumsum(IRF_b(3,:));
         IRF4(sim,:) = cumsum(IRF_b(4,:));
	 srrsim(sim) = IRF2(sim,1);
      end

      stdsrr = std(srrsim);
      end
      cd ..
      %-------------------------------------------------------------------------
      % TABLE 2
      %------------------------------------------------------------------------- 
      if siccode(sicn)>1000
         if mod(siccode(sicn),100)==0     % 2 digit
	    rw=1;
	 elseif mod(siccode(sicn),10)==0  % 3 digit
	    rw=3;
	 else
	    rw=5;
	 end

	 if g_var==2
            sig2 = abs(srr/stdsrr)>=norminv(0.95); % 10% significance
         end

	 if srr<0
	    cl=1;
	 else
	    cl=2;
	 end

         if (rw>0)
   	    table6(rw,cl)=table6(rw,cl)+1;
	    if g_var==2 & sig2==1
	       table6(rw+1,cl)=table6(rw+1,cl)+1;
	    end
	 end
      end
 end
 
delete('result/table6aB.txt')
diary('result/table6aB.txt')
disp(['Created  ' datestr(now)])
disp(' ')
disp('Program Used "table6a_basu.m"')
disp(' ')
disp('=================================================================')
disp('  VAR MODEL with (dTFP(basu),dlog(total hour))')   
disp('  estimated by Aggregation method')
disp('=================================================================')
disp('  SRR result')
disp('  2 digit, 3 digit 4digit PANEL')
disp('  NEGATIVE    POSITIVE')
disp('=================================================================')
disp(num2str(table6))
disp('=================================================================')
diary off

