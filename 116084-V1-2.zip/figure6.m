%========================================================================= 
% figure6.m
%
% produce figure6 in ��Do Technological Improvements 
% in the Manufacturing Sector Raise or Lower Employment? 
% (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
%
% input: data files
%        srr_4digit.dat srr_4digit_3var_agg.dat
%        srr_4digit_4var.dat
%
% output: fig6_sticky_robust.eps
% 
% written by:
% Jay H. Hong, Dept of Economics
% University of Pennsylvania
% 3718 Locust Walk
% Philadelphia, PA 19104
% jayhwa@econ.upenn.edu
%=========================================================================


clc
clear all
close all

%-------------------------------------------------------------------------
% load dataset
%-------------------------------------------------------------------------

cd ./data
load srr_4digit.dat
load srr_4digit_3var_agg.dat
load srr_4digit_4var.dat
cd ..

sic = srr_4digit(:,1);
srr_2var = srr_4digit(:,3);
srr_3var_agg = srr_4digit_3var_agg(:,3);
srr_4var = srr_4digit_4var(:,3);

corr_ = corrcoef(srr_2var, srr_3var_agg)
corr_3_agg = num2str(corr_(2,1),'%4.2f')
corr_ = corrcoef(srr_2var, srr_4var)
corr_4 = num2str(corr_(2,1),'%4.2f')

set(0,'DefaultFigurePaperOrientation','portrait')
set(0,'DefaultLineLineWidth',2)
set(0,'DefaultAxesLineWidth',1)
set(0,'DefaultAxesFontSize',12)



f1=figure;
subplot(2,1,1); plot(srr_2var,srr_3var_agg,'.')
title('Bivariate VAR vs. Tri-variate VAR with Agg TFP')
xlabel('Bivariate VAR');ylabel('Tri-variate VAR with aggregate TFP')
text(max(srr_2var)-1, max(srr_3var_agg)-1, corr_3_agg,'FontSize',12); 

subplot(2,1,2); plot(srr_2var,srr_4var,'.')
title('Bivariate VAR vs. 4-variate VAR')
xlabel('Bivariate VAR');ylabel('4-variate VAR')
text(max(srr_2var)-1, max(srr_4var)-1, corr_4,'FontSize',12); 
set(f1,'PaperPosition', [0.5 1.75 4.5 8.5])

print ./result/fig6_sticky_robust -depsc

