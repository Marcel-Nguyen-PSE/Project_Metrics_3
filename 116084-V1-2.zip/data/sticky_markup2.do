* filename: sticky_markup2.do
* read date from Bartlesman and Gray's NBER Productivity Data Set for 58-94
* True TFP = measured TFP +(myu-1)*(sn*(dn-dk)+sm*(dm-dk))
* where myu denotes the markup ratio
* This program aggregate uses the revenue share as an industry weight 

clear all
set mem 32m
use nber_adjust
drop if sic==3292  /* drop Asbestos Products (missing observation) */
gen hrs = prodh+(emp-prode)*(52*40)/1000  
gen mat = matcost/pimat
gen ene = energy/pien
gen y = vship/piship
gen v = vadd/piship
preserve

restore
preserve
replace sic = 0
sort sic year
collapse (rawsum) y hrs vship (mean) tfp piship [weight=vship], by(year sic)
sort sic year
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
sort sic year
gen dp = dy-dn
sort year
keep if year>58
outfile tfp dn using manux.dat, replace
outfile dp dn using manup.dat, replace


restore
preserve
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm = matcost/vship if sm==.
gen dx = sn*(dn-dk) + sm*(dm-dk)
gen myu=1.1
replace tfp = tfp - (myu-1)*dx
replace sic = 0
sort sic year
collapse (rawsum) hrs (mean) tfp piship [weight=vship], by(year sic)
sort sic year
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
sort year
keep if year>58
outfile tfp dn using manu_markup_11.dat, replace


restore
preserve
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm = matcost/vship if sm==.
gen dx = sn*(dn-dk) + sm*(dm-dk)
gen myu=1.05
replace tfp = tfp - (myu-1)*dx
replace sic = 0
sort sic year
collapse (rawsum) hrs (mean) tfp piship [weight=vship], by(year sic)
sort sic year
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
sort year
keep if year>58
outfile tfp dn using manu_markup_105.dat, replace


*******************************************************************************************

restore
preserve
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dv=log(v/v[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
replace sm=matcost/vship if sm==.
replace sn=pay/vship if sn==.
gen dx = sn*(dn-dk) + sm*(dm-dk)
gen myu =1
replace tfp = tfp - (myu-1)*dx
*replace tfp = tfp/(1-myu*sm)
replace sic = sic-mod(sic,100)
sort sic year
collapse (rawsum) v vadd hrs (mean) sm tfp piship [weight=vadd], by(year sic)
gen myu =1
replace tfp = tfp/(1-myu*sm)
replace sic = 0
sort sic year
collapse (rawsum) v vadd hrs (mean) tfp piship [weight=vadd], by(year sic)
sort year
gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
gen dv=log(v/v[_n-1]) if year==year[_n-1]+1 
gen dp = dv-dn
sort year
keep if year>58
outfile tfp dn using manuxv.dat, replace
outfile dp dn using manupv.dat, replace

restore
preserve
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dv=log(v/v[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
replace sm=matcost/vship if sm==.
replace sn=pay/vship if sn==.
gen dx = sn*(dn-dk) + sm*(dm-dk)
gen myu =1.1
replace tfp = tfp - (myu-1)*dx
*replace tfp = tfp/(1-myu*sm)
replace sic = sic-mod(sic,100)
sort sic year
collapse (rawsum) v vadd hrs (mean) sm tfp piship [weight=vadd], by(year sic)
gen myu =1.1
replace tfp = tfp/(1-myu*sm)
replace sic = 0
sort sic year
collapse (rawsum) hrs (mean) tfp piship [weight=vadd], by(year sic)
sort year
gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
sort year
keep if year>58
outfile tfp dn using manu_markupv_11.dat, replace

restore
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dv=log(v/v[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
replace sm=matcost/vship if sm==.
replace sn=pay/vship if sn==.
gen dx = sn*(dn-dk) + sm*(dm-dk)
gen myu =1.05
replace tfp = tfp - (myu-1)*dx
*replace tfp = tfp/(1-myu*sm)
replace sic = sic-mod(sic,100)
sort sic year
collapse (rawsum) v vadd hrs (mean) sm tfp piship [weight=vadd], by(year sic)
gen myu =1.05
replace tfp = tfp/(1-myu*sm)
replace sic = 0
sort sic year
collapse (rawsum) hrs (mean) tfp piship [weight=vadd], by(year sic)
sort year
gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
sort year
keep if year>58
outfile tfp dn using manu_markupv_105.dat, replace

