* filename: sticky_basu.do
* see readme file

clear all 
set mem 32m
use nber_adjust_basu

*********************************************************
program define detrend, byable(recall,noheader)

marksample touse
quietly reg ln year if `touse'
quietly predict e if e(sample), resid
quietly replace nhat = e if e(sample)
drop e

end
*********************************************************

drop if sic==3292  /* drop Asbestos Products (missing observation) */
gen hrs = prodh+(emp-prode)*(52*40)/1000  
gen mat = matcost/pimat
gen y=vship/piship
keep emp hrs matcost pay vship vadd cap mat y tfp lfact year sic ee sm
gen durable = 1 if (sic>2400 & sic<2600) | (sic>3200)
gen nondurable = 1 if durable~=1

preserve

replace sic = 0
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vship], by(year sic)
sort sic year
save managg, replace

restore
preserve

replace sic = 0
replace ee=ee/(1-sm)
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vadd], by(year sic)
sort sic year
save managgv, replace


restore
preserve


replace sic = 1 if durable==1
replace sic = 2 if nondurable==1

sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vship], by(year sic)
sort sic year
save mandnd, replace

restore
preserve
replace sic = sic - mod(sic,100)
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vship], by(year sic)
sort sic year
save 2digit, replace

restore
preserve
replace sic = sic - mod(sic,10)
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vship], by(year sic)
sort sic year
save 3digit, replace


restore
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vship], by(year sic)
sort sic year

append using managg
append using mandnd
append using 2digit
append using 3digit

erase managg.dta
erase mandnd.dta
erase 2digit.dta
erase 3digit.dta

sort sic year

replace tfp=0 if tfp==.

quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
gen dp = dy - dn


replace dn=0 if dn==.
replace dp=0 if dp==.
replace dk=0 if dk==.
replace dy=0 if dy==.
replace dm=0 if dm==.

outfile sic year ee dp dn dk dm using manu2_basu.dat if year>58, replace wide
keep if sic==0
outfile ee dn using manuB4x.dat if year>58, replace wide

use managgv.dta, clear
erase managgv.dta

sort sic year

quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
gen dp = dy - dn


replace dn=0 if dn==.
replace dp=0 if dp==.
replace dk=0 if dk==.
replace dy=0 if dy==.
replace dm=0 if dm==.

outfile sic year ee dp dn dk dm using manu2_basu_v.dat if year>58, replace wide
keep if sic==0
outfile ee dn using manuB4xv.dat if year>58, replace wide
