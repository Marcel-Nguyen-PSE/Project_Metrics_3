* filename: basu_tfp_4.do
* see readme file

clear all
set mem 300m 
set more off

*********************************************************
program define basu_inst

   infile year oil1 gov1 money1 using basu_instrument.txt
   * year, oilprice, military purchases by governement, monetary shocks: these variable are one-period lagged already
   sort year
   gen oil=oil1[_n+1] if year==year[_n+1]-1
   gen gov=gov1[_n+1] if year==year[_n+1]-1
   gen money=money1[_n+1] if year==year[_n+1]-1
   keep if year>=58
   keep if year<=96
   sort year
   save basu_instrument, replace
   clear
   
end
   
*********************************************************
program define basu4


   *--------------------------------------------------------
   * counting & indexing 4 digit industries in each 3-digit
   *--------------------------------------------------------
   quietly save temp,replace
   collapse sic3, by(sic)
   mkmat sic, matrix(n_sic)
   use temp, clear
   erase temp.dta
   scalar n=rowsof(n_sic)
   gen sicn=0

   forvalue i=1/10 {
      local j=n_sic[`i',1]
      quietly replace sicn=`i' if sic==`j'
   }

   *--------------------------------------------------------
   * reshaping data-set into widen-format
   *--------------------------------------------------------
   quietly keep year dy dx dh sm sicn
   quietly reshape wide dx dy dh sm, i(year) j(sicn)

   merge year using basu_instrument



   *--------------------------------------------------------
   * declaring regression equations & constraints
   *--------------------------------------------------------
   forvalues i=1/10 {
      global dy`i' (dy`i' dx`i' dh`i') 
*      if `i'~=1 {
      constraint define `i' [dy`i']dh`i' = [dy1]dh1
 *     }
   }

   *--------------------------------------------------------
   * run 3SLS regression
   *--------------------------------------------------------
   quietly if n==10 reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7 $dy8 $dy9 $dy10, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-10)
   quietly if n==9  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7 $dy8 $dy9, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-9)
   quietly if n==8  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7 $dy8, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-8)
   quietly if n==7  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-7)
   quietly if n==6  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-6)
   quietly if n==5  reg3 $dy1 $dy2 $dy3 $dy4 $dy5, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-5)
   quietly if n==4  reg3 $dy1 $dy2 $dy3 $dy4, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-4)
   quietly if n==3  reg3 $dy1 $dy2 $dy3, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-3)
   quietly if n==2  reg3 $dy1 $dy2, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-2)
   quietly if n==1  reg3 $dy1, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil)

   *--------------------------------------------------------
   * obtaining coefficient vector 
   * and collecting residuals for 'corrected' TFP series
   * and logging output
   *--------------------------------------------------------
   matrix b=e(b)'
   matrix v=vecdiag(e(V))'
   scalar nb=rowsof(b)/n
   forvalues i=1/10 {
      if `i'<=n {
         quietly predict ee`i', resid eq(dy`i')    /* RESIDUAL */
         quietly replace ee`i'=ee`i'+b[nb*`i',1]   /* ADDING CONSTANT TERM */

         * output

	 disp %5.0f n_sic[`i',1] %7.3f b[nb*(`i'-1)+1,1] "   " %7.3f b[nb*(`i'-1)+2,1] "   "  %7.3f b[nb*`i',1]
	 disp "    ("            %7.3f sqrt(v[nb*(`i'-1)+1,1]) ") (" %7.3f sqrt(v[nb*(`i'-1)+2,1]) ") (" %7.3f sqrt(v[nb*`i',1]) ")"

      }
   }

   *--------------------------------------------------------
   * reshaping data-set into long-format
   *--------------------------------------------------------
   keep year ee* sm*
   quietly reshape long ee sm, i(year) j(sicn)

   *--------------------------------------------------------
   * restoring original SIC index
   *--------------------------------------------------------
   g sic=0
   forvalue i=1/10 {
      local j=n_sic[`i',1]
      quietly replace sic=`j' if sicn==`i'
   }
   drop sicn
   order sic year ee sm

   *--------------------------------------------------------
   * record keeping
   *--------------------------------------------------------
   if niter>1 {
      append using basu_tfp, keep(year sic ee sm) 
   }
   quietly save basu_tfp, replace
   
end
*********************************************************

*********************************************************
* MAIN PROGRAM
*********************************************************

basu_inst /* load & save basu_instrument variables */

use nber_adjust


*--------------------------------------------------------
* some data cleaning
*--------------------------------------------------------
drop if sic==3292  /* drop Asbestos Products (missing observation) */
gen hrs = prodh+(emp-prode)*(52*40)/1000  
gen mat = matcost/pimat
gen ene = energy/pien
gen y = vship/piship
gen v = vadd/piship
gen h = 1000*prodh/(prode*52)
sort sic year

*--------------------------------------------------------
* generate variables for dy=gamma*dx+beta*dh+e
*--------------------------------------------------------
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dh=log(h/h[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm=matcost/vship if sm==.

gen sk=1-sm-sn
gen dx = sn*dn + sm*dm + sk*dk
keep if year>=58
keep  year sic dx dy dh sm

*--------------------------------------------------------
* grouping sub-industries within same 3-digit catagory
* & run Basu regressions for each 3-digit industry
*--------------------------------------------------------
gen sic3= sic - mod(sic,10)
scalar niter=1
log using basu_tfp_4.log, replace
forvalue sici=201/399 {
   preserve
   quietly egen match=count(sic) if sic3==`sici'*10
   quietly egen nmatch=sum(match)
   if nmatch>0 {
      disp `sici'
      quietly keep if sic3==`sici'*10
      basu4             * CALLING SUBROUTINE
      scalar niter=niter+1
   }
   restore
}
log close
program drop _all

*--------------------------------------------------------
* final cleaning
*--------------------------------------------------------
use basu_tfp, clear
sort sic year
save basu_tfp, replace

merge using nber_adjust

save nber_adjust_basu, replace
