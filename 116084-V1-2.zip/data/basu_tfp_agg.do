* filename: basu_tfp_agg.do
* see readme file

clear all
set mem 300m 
set more off

*********************************************************
program define basu_inst

   infile year oil1 gov1 money1 using basu_instrument.txt
   * year, oilprice, military purchases by governement, monetary shocks: these variable are one-period lagged already
   sort year
   gen oil=oil1[_n+1] if year==year[_n+1]-1
   gen gov=gov1[_n+1] if year==year[_n+1]-1
   gen money=money1[_n+1] if year==year[_n+1]-1
   keep if year>=58
   keep if year<=96
   sort year
   save basu_instrument, replace
   clear
   
end
   
*********************************************************
program define basu4


   *--------------------------------------------------------
   * counting & indexing
   *--------------------------------------------------------
   quietly save temp,replace
   collapse ndr dur, by(sic)
   mkmat sic, matrix(n_sic)
   use temp, clear
   erase temp.dta
   scalar n=rowsof(n_sic)
   gen sicn=0

   forvalue i=1/10 {
      local j=n_sic[`i',1]
      quietly replace sicn=`i' if sic==`j'
   }

   *--------------------------------------------------------
   * reshaping data-set into widen-format
   *--------------------------------------------------------
   quietly keep year dy dx dh sm sicn
   quietly reshape wide dx dy dh sm, i(year) j(sicn)

   merge year using basu_instrument



   *--------------------------------------------------------
   * declaring regression equations & constraints
   *--------------------------------------------------------
   forvalues i=1/10 {
      global dy`i' (dy`i' dx`i' dh`i') 
      constraint define `i' [dy`i']dh`i' = [dy1]dh1
   }

   *--------------------------------------------------------
   * run 3SLS regression
   *--------------------------------------------------------
   quietly if n==10 reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7 $dy8 $dy9 $dy10, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-10)
   quietly if n==9  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7 $dy8 $dy9, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-9)
   quietly if n==8  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7 $dy8, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-8)
   quietly if n==7  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6 $dy7, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-7)
   quietly if n==6  reg3 $dy1 $dy2 $dy3 $dy4 $dy5 $dy6, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-6)
   quietly if n==5  reg3 $dy1 $dy2 $dy3 $dy4 $dy5, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-5)
   quietly if n==4  reg3 $dy1 $dy2 $dy3 $dy4, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-4)
   quietly if n==3  reg3 $dy1 $dy2 $dy3, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-3)
   quietly if n==2  reg3 $dy1 $dy2, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil) constr(2-2)
   quietly if n==1  reg3 $dy1, endog(dy* dx* dh*) exog(oil1 gov1 money1 gov oil)

   *--------------------------------------------------------
   * obtaining coefficient vector 
   * and collecting residuals for 'corrected' TFP series
   * and logging output
   *--------------------------------------------------------
   matrix b=e(b)'
   matrix v=vecdiag(e(V))'
   scalar nb=rowsof(b)/n
   forvalues i=1/10 {
      if `i'<=n {
         quietly predict ee`i', resid eq(dy`i')    /* RESIDUAL */
         quietly replace ee`i'=ee`i'+b[nb*`i',1]   /* ADDING CONSTANT TERM */

         * output

	 disp %5.0f n_sic[`i',1] %6.2f b[nb*(`i'-1)+1,1] "   " %6.2f b[nb*(`i'-1)+2,1] "   "  %6.2f b[nb*`i',1]
	 disp "    ("            %6.2f sqrt(v[nb*(`i'-1)+1,1]) ") (" %6.2f sqrt(v[nb*(`i'-1)+2,1]) ") (" %6.2f sqrt(v[nb*`i',1]) ")"

      }
   }

   *--------------------------------------------------------
   * reshaping data-set into long-format
   *--------------------------------------------------------
   keep year ee* sm*
   quietly reshape long ee sm, i(year) j(sicn)

   *--------------------------------------------------------
   * restoring original SIC index
   *--------------------------------------------------------
   g sic=0
   forvalue i=1/10 {
      local j=n_sic[`i',1]
      quietly replace sic=`j' if sicn==`i'
   }
   drop sicn
   order sic year ee sm

   *--------------------------------------------------------
   * record keeping
   *--------------------------------------------------------
   if niter>1 {
      append using basu_tfp_a, keep(year sic ee sm) 
   }
   quietly save basu_tfp_a, replace
   
end
*********************************************************

*********************************************************
* MAIN PROGRAM
*********************************************************

basu_inst /* load & save basu_instrument variables */

use nber_adjust


*--------------------------------------------------------
* some data cleaning
*--------------------------------------------------------
drop if sic==3292  /* drop Asbestos Products (missing observation) */
gen hrs = prodh+(emp-prode)*(52*40)/1000  
gen mat = matcost/pimat
gen ene = energy/pien
gen y = vship/piship
gen v = vadd/piship
replace sic = sic - mod(sic,100)
save basu_agg_temp, replace
sort sic year
collapse (rawsum) y hrs mat cap prodh prode matcost vship pay vadd (mean) tfp lfact [weight=vship], by(year sic)
gen h = 1000*prodh/(prode*52)
sort sic year

*--------------------------------------------------------
* generate variables for dy=gamma*dx+beta*dh+e
*--------------------------------------------------------
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dh=log(h/h[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm=matcost/vship if sm==.

gen sk=1-sm-sn
gen dx = sn*dn + sm*dm + sk*dk
keep if year>=58
g sicn=sic/100
g dur=1 if sicn==24 | sicn==25 | sicn>31
g ndr=1 if dur~=1
keep  year sic dx dy dh sm dur ndr

*--------------------------------------------------------
* grouping sub-industries within same 3-digit catagory
* & run Basu regressions for each 3-digit industry
*--------------------------------------------------------
scalar niter=1
log using ../result/table5.txt, replace text


preserve
disp "DURABLES"
quietly keep if dur==1
basu4

scalar niter=niter+1
restore
preserve
disp "NONDURABLES"
quietly keep if ndr==1
basu4

scalar niter=niter+1
restore

log close
program drop _all

*--------------------------------------------------------
* final cleaning
*--------------------------------------------------------
use basu_tfp_a, clear
sort sic year
save basu_tfp_a, replace

* gross output share
use basu_agg_temp, clear
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) tfp lfact [weight=vship], by(year sic)
sort sic year

merge using basu_tfp_a

replace sic = 0
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vship], by(year sic)
sort sic year
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
gen dp = dy - dn

outfile sic year ee dp dn dk dm using manu2_basu_ag.dat if year>58, replace wide
outfile ee dn using manuB2x.dat if year>58, replace wide

* value-added output share (domar weight)
use basu_agg_temp, clear
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) tfp lfact [weight=vadd], by(year sic)
sort sic year

merge using basu_tfp_a

replace sic = 0
replace ee = ee/(1-sm)
sort sic year
collapse (rawsum) emp hrs matcost pay vship vadd cap mat y (mean) ee tfp lfact [weight=vadd], by(year sic)
sort sic year
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
gen dp = dy - dn

outfile sic year ee dp dn dk dm using manu2_basu_ag_v.dat if year>58, replace wide
outfile ee dn using manuB2xv.dat if year>58, replace wide

erase basu_agg_temp.dta
erase basu_instrument.dta


