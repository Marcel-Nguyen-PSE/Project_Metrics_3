*========================================================================= 
* table4.do
*
* produce table4 in ��Do Technological Improvements 
* in the Manufacturing Sector Raise or Lower Employment? 
* (AER manuscript # 20030462)�� by Yongsung Chang and Jay H. Hong
*
* input: data files
*        nber_adjust
*
* output: table4.txt
*
*=========================================================================

clear all
set mem 32m
set more off
cd data
use nber_adjust
cd ..
replace year = 1900+year
drop if sic==3292  /* drop Asbestos Products (missing observation) */
gen hrs = prodh+(emp-prode)*(52*40)/1000  
gen mat = matcost/pimat
gen ene = energy/pien
gen y = vship/piship
gen durable = 1 if (sic>2400 & sic<2600) | (sic>3200)
replace durable = 0 if durable~=1
preserve 

restore
preserve
replace sic = sic - mod(sic,100)
sort sic year
collapse (rawsum) y hrs mat cap prodh prode matcost vship pay vadd (mean) tfp lfact [weight=vship], by(year sic)
gen h = 1000*prodh/(prode*52)
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dh=log(h/h[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm=matcost/vship if sm==.
gen sk=1-sm-sn
gen dx = sn*dn + sm*dm + sk*dk
gen dp = dy - dn
gen dmn = sm*(dm - dn)
gen dkn = sk*(dk - dn)
sort sic
by sic: egen m_tfp=mean(tfp)
by sic: egen m_prod=mean(dp)
by sic: egen m_mn=mean(dmn)
by sic: egen m_kn=mean(dkn)
replace year =0
sort year sic
collapse  (mean) m_tfp m_prod m_mn m_kn, by(sic)
replace m_tfp = 100*m_tfp
replace m_prod = 100*m_prod
replace m_mn = 100*m_mn
replace m_kn = 100*m_kn

save temp, replace

restore
preserve
replace sic=1 if durable==1
replace sic=2 if durable==0
sort sic year
collapse (rawsum) y hrs mat cap prodh prode matcost vship pay vadd (mean) tfp lfact [weight=vship], by(year sic)
gen h = 1000*prodh/(prode*52)
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dh=log(h/h[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm=matcost/vship if sm==.
gen sk=1-sm-sn
gen dp = dy - dn
gen dmn = sm*(dm - dn)
gen dkn = sk*(dk - dn)
sort sic
by sic: egen m_tfp=mean(tfp)
by sic: egen m_prod=mean(dp)
by sic: egen m_mn=mean(dmn)
by sic: egen m_kn=mean(dkn)
replace year = 0
sort year sic
collapse  (mean) m_tfp m_prod m_mn m_kn, by(sic)
replace m_tfp = 100*m_tfp
replace m_prod = 100*m_prod
replace m_mn = 100*m_mn
replace m_kn = 100*m_kn

append using temp
save temp, replace

restore
preserve
replace sic = 0
sort sic year
collapse (rawsum) y hrs mat cap prodh prode matcost vship pay vadd (mean) tfp lfact [weight=vship], by(year sic)
gen h = 1000*prodh/(prode*52)
sort sic year
quietly by sic: gen sm=(matcost+matcost[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen sn=(pay+pay[_n-1])/(vship+vship[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dn=log(hrs/hrs[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dk=log(cap/cap[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dm=log(mat/mat[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dy=log(y/y[_n-1]) if year==year[_n-1]+1 
quietly by sic: gen dh=log(h/h[_n-1]) if year==year[_n-1]+1 
replace sn=pay/vship if sn==.
replace sm=matcost/vship if sm==.
gen sk=1-sm-sn
gen dp = dy - dn
gen dmn = sm*(dm - dn)
gen dkn = sk*(dk - dn)
sort sic
by sic: egen m_tfp=mean(tfp)
by sic: egen m_prod=mean(dp)
by sic: egen m_mn=mean(dmn)
by sic: egen m_kn=mean(dkn)
replace year = 0
sort year sic
collapse  (mean) m_tfp m_prod m_mn m_kn, by(sic)
replace m_tfp = 100*m_tfp
replace m_prod = 100*m_prod
replace m_mn = 100*m_mn
replace m_kn = 100*m_kn
append using temp

log using ./result/table4.txt, replace text
* -------------------------------
* note: sic=0 all manufacturing
*       sic=1 durables 
*       sic=2 nondurables
* -------------------------------
list sic m_prod m_tfp m_mn m_kn 
log close

erase temp.dta
