This document is to guide a user how to use m-files to replicate simulation 
results in the paper, which is entitled ��Do Technological Improvements in the 
Manufacturing Sector Raise or Lower Employment? (AER manuscript # 20030462)�� 
by Yongsung Chang and Jay H. Hong.

---------------------------------------------------------------------
1.Data files
---------------------------------------------------------------------

(1) raw data
bbg96_87.dta	: We use the "NBER-CES Manufacturing Industry Database" by 
                  Bartelsman, Becker, and Gray. This can be downloaded at 
		  http://www.nber.org/nberces/nbprod96.htm

(2) final data

  (A) manu2.dat	: This contains the growth rate of TFP, Labor Productivity,  
                  Hours, Capital and Material by each SIC industries. 
		  TFP measure here is "revenue-weighted" gross TFP.
	
	          To generate this file, one can do the followings.
		   (A-1) Run stata do file "nber_laborshare_adjust.do" to 
		   adjust fringe benefits from the raw data. This generates 
		   stata file "nber_adjust.dta"
		   (A-2) Run stata do file  "sticky_rev2.do" to get "manu2.dat" 
		   using "nber_adjust.dta"

  (B) manu2_basu.dat : Corrected TFP measure following Basu et al. (2005)

	          To generate this file, one can do the followings.
		   (B-1) Run stata do file "nber_laborshare_adjust.do" to 
		   adjust fringe benefits from the raw data. This generates 
		   stata file "nber_adjust.dta".
		   (B-2) Run stata do file  "basu_tfp_4.do" to run 3SLS 
		   regression using IV (basu_instrument.txt). This generates 
		   stata file "nber_adjust_basu.dta".
		   (B-3) Run stata do file  "sticky_basu.do" to get 
		   "manu2_basu.dat".

  (C) MARKUP ADJUSTMENT: Run "sticky_markup2.do" to get productivity measures of 
                  manufacturing aggregate with various assumptions.

	weight	Gross output		Value Added
		------------		-----------
	TFP1.0	manux.dat 		manuxv.dat 
	TFP1.05	manu_markup_105.dat 	manu_markup_11.dat
	TFP1.1	manu_markupv_105.dat 	manu_markupv_11.dat
	LP	manup.dat 		manupv.dat

  (D) Basu et al. correction : The TFP measure of manufacturing aggregate with 
                   2-digit or 4-digit production function by running 
		   "basu_tfp_agg.do" or "sticky_basu.do" respectively.

	2digit	manuB2x.dat		manuB2xv.dat	(basu_tfp_agg.do)
	4digit	manuB4x.dat		manuB4xv.dat  	(sticky_basu.do)


  (E) sticky_month.dat : Bils-Klenow (2004) measure of prices stickiness. 
                         SIC and average duration.

  (F) aggregate.dat : Non-farm business TFP, Output, and hours index from BLS.

  (G) manu_perhour.dat : growth rate of input per hour (manufacturing aggregate)


---------------------------------------------------------------------
2. Description of simulation files
---------------------------------------------------------------------

  table12a.m		: matlab m-file for table 1,2(a) and figure 1
  table2p.m		: matlab m-file for table 2(p) (pooled data)
  table3a.m		: matlab m-file for table 3(a) (aggregated data)
  table3p.m		: matlab m-file for table 3(p)
  table4.do		: stata do-file for table 4
  table6a_basu.m	: matlab m-file for table 6(a)
  table6p_basu.m	: matlab m-file for table 6(p)
  table7.m		: matlab m-file for table 7
  figure2_a.m		: matlab m-file for figure 2
  figure4.m		: matlab m-file for figure 4
  figure5.m		: matlab m-file for figure 5
  figure6.m		: matlab m-file for figure 6
  figure7.m		: matlab m-file for figure 7

 Note:
  1) All common routines are in the "routine" directory.
  2) All output files will be stored in the "result" directory.
  3) To generate table5, run stata do-file "basu_tfp_agg.do" in <data> folder.

